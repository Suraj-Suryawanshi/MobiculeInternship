package com.company.jmix_drill.security;

import com.company.jmix_drill.entity.Task;
import io.jmix.security.role.annotation.JpqlRowLevelPolicy;
import io.jmix.security.role.annotation.RowLevelRole;

@RowLevelRole(name = "dev", code = DevRole.CODE)
public interface DevRole {
    String CODE = "dev";

    @JpqlRowLevelPolicy(
            entityClass = Task.class,
            where = "{E}.assignee.id = :current_user_id")
    void task();
}

//@RowLevelRole(
//        name = "Can see only Orders created by themselves",
//        code = "orders-created-by-themselves")
//public interface CreatedByMeOrdersRole {
//
//    @JpqlRowLevelPolicy(
//            entityClass = Order.class,
//            where = "{E}.createdBy = :current_user_username")
//    void order();
//}