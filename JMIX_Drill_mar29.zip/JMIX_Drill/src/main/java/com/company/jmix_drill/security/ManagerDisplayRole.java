package com.company.jmix_drill.security;

import com.company.jmix_drill.entity.Project;
import com.company.jmix_drill.entity.Task;
import io.jmix.security.role.annotation.JpqlRowLevelPolicy;
import io.jmix.security.role.annotation.RowLevelRole;

@RowLevelRole(name = "managerDisplay", code = ManagerDisplayRole.CODE)
public interface ManagerDisplayRole {
    String CODE = "manager-display";

    @JpqlRowLevelPolicy(
            entityClass = Project.class,
            where = "{E}.manager.id = :current_user_id"
    )
    void project();

    @JpqlRowLevelPolicy(
            entityClass = Task.class,
            where = "{E}.manager.id = :current_user_id")
    void task();
}