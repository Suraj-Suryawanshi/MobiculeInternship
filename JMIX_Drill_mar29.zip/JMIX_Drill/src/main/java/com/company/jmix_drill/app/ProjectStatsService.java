package com.company.jmix_drill.app;

import com.company.jmix_drill.entity.Project;
import com.company.jmix_drill.entity.ProjectStat;
import com.company.jmix_drill.entity.Task;
import io.jmix.core.DataManager;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class ProjectStatsService {
    private final DataManager dataManager;

    public ProjectStatsService(DataManager dataManager) {
        this.dataManager = dataManager;
    }

    public List<ProjectStat> fetchProjectsStatistics(){
        List<Project> projects = dataManager.load(Project.class).all().fetchPlan("project-with-tasks").list();
        List<ProjectStat> projectStats=projects.stream().map(project -> {
            ProjectStat stat = dataManager.create(ProjectStat.class);
            stat.setProjectId(project.getId());
            stat.setProjectName(project.getName());
            stat.setTasksCount(project.getTasks().size());
            stat.setActualEfforts(getActualEfforts(project.getId()));
            Integer estimatedEfforts = 0;
            for (Task task : project.getTasks()) {
                estimatedEfforts += task.getEstimatedEfforts();
            }
            //Integer estimatedEfforts = project.getTasks().stream().map(Task::getEstimatedEfforts).reduce(0,Integer::sum);
            stat.setPlannedEfforts(estimatedEfforts);

            return stat;
        }).collect(Collectors.toList());
        return projectStats;
    }

    public Integer getActualEfforts(UUID projectId){
        return dataManager.loadValue("select sum(te.timeSpent) from TimeEntry te " +
                        "where te.task.project.id = :projectId",Integer.class)
                .parameter("projectId",projectId).one();
    }
}