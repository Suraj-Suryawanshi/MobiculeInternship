package com.company.jmix_drill.screen.main;

import com.company.jmix_drill.app.TaskService;
import com.company.jmix_drill.entity.Project;
import com.company.jmix_drill.entity.Task;
import io.jmix.ui.Notifications;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.ScreenTools;
import io.jmix.ui.action.Action;
import io.jmix.ui.component.*;
import io.jmix.ui.component.mainwindow.Drawer;
import io.jmix.ui.icon.JmixIcon;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.model.CollectionLoader;
import io.jmix.ui.navigation.Route;
import io.jmix.ui.screen.*;
import org.springframework.beans.factory.annotation.Autowired;
import java.time.LocalDateTime;

@UiController("MainScreen")
@UiDescriptor("main-screen.xml")
@Route(path = "main", root = true)
public class MainScreen extends Screen implements Window.HasWorkArea {


    @Autowired
    private TaskService taskService;
    @Autowired
    private EntityComboBox<Project> projectSelector;
    @Autowired
    private MessageBundle messageBundle;
    @Autowired
    private Notifications notifications;
    @Autowired
    private DateField<LocalDateTime> dateSelector;
    @Autowired
    private TextField<String> nameSelector;
    @Autowired
    private ScreenTools screenTools;

    @Autowired
    private AppWorkArea workArea;
    @Autowired
    private Drawer drawer;
    @Autowired
    private Button collapseDrawerButton;
    @Autowired
    private CollectionLoader<Project> projectsDl;
    @Autowired
    private CollectionLoader<Task> tasksDl;
    @Autowired
    private CollectionContainer<Task> tasksDc;
    @Autowired
    private ScreenBuilders screenBuilders;
    @Autowired
    private TextField<Integer> estimatedEffortsSelector;


    @Override
    public AppWorkArea getWorkArea() {
        return workArea;
    }

    @Subscribe("collapseDrawerButton")
    private void onCollapseDrawerButtonClick(Button.ClickEvent event) {
        drawer.toggle();
        if (drawer.isCollapsed()) {
            collapseDrawerButton.setIconFromSet(JmixIcon.CHEVRON_RIGHT);
        } else {
            collapseDrawerButton.setIconFromSet(JmixIcon.CHEVRON_LEFT);
        }
    }

    @Subscribe
    public void onAfterShow(AfterShowEvent event) {
        screenTools.openDefaultScreen(
                UiControllerUtils.getScreenContext(this).getScreens());

        screenTools.handleRedirect();
    }

    @Subscribe("refreshAction")
    public void onRefreshAction(final Action.ActionPerformedEvent event) {
        projectsDl.load();
        tasksDl.load();

    }

    @Subscribe("addTaskAction")
    public void onAddTaskAction(final Action.ActionPerformedEvent event) {
        if (projectSelector.getValue()==null || nameSelector.getValue()==null || dateSelector.getValue()==null) {
            notifications.create().withCaption(messageBundle.getMessage("validation.fieldsNotFilled.message"))
                    .withType(Notifications.NotificationType.WARNING).show();

            projectSelector.focus();
            return;
        }
        taskService.createTask(projectSelector.getValue(),nameSelector.getValue(),dateSelector.getValue(),estimatedEffortsSelector.getValue());
        tasksDl.load();

        projectSelector.setValue(null);
        nameSelector.setValue(null);
        dateSelector.setValue(null);
        estimatedEffortsSelector.setValue(null);

    }

    @Subscribe("tasksCalender")
    public void onTasksCalenderCalendarEventClick(final Calendar.CalendarEventClickEvent<LocalDateTime> event) {
        Task task = (Task) event.getEntity();
        if(task == null){
            return;
        }
        Screen screen = screenBuilders.editor(Task.class,this)
                .editEntity(task)
                .withOpenMode(OpenMode.DIALOG)
                .build();

        screen.addAfterCloseListener(afterCloseEvent -> {
            if(afterCloseEvent.closedWith(StandardOutcome.COMMIT)){
                tasksDl.load();
            }
            });
            screen.show();
        }


    }
    



