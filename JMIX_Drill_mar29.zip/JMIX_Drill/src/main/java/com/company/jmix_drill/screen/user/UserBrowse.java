package com.company.jmix_drill.screen.user;

import com.company.jmix_drill.entity.User;
import io.jmix.ui.Notifications;
import io.jmix.ui.UiComponents;
import io.jmix.ui.component.Component;
import io.jmix.ui.component.FileStorageResource;
import io.jmix.ui.component.Image;
import io.jmix.ui.component.PropertyFilter;
import io.jmix.ui.navigation.Route;
import io.jmix.ui.screen.*;
import org.springframework.beans.factory.annotation.Autowired;

@UiController("User.browse")
@UiDescriptor("user-browse.xml")
@LookupComponent("usersTable")
@Route("users")
public class UserBrowse extends StandardLookup<User> {

    @Autowired
    private Notifications notifications;
    @Autowired
    private UiComponents uiComponents;


    @Subscribe("propertyFilter")
    public void onPropertyFilterOperationChange(final PropertyFilter.OperationChangeEvent event) {

//            notifications.create(Notifications.NotificationType.TRAY)
//                    .withCaption("Before: " + event.getPreviousOperation().name() + "\n"
//                            + "After: " + event.getNewOperation().name())
//                    .show();
        }

    @Install(to = "usersTable.picture", subject = "columnGenerator")
    private Component usersTablePictureColumnGenerator(final User user) {
        if (user.getPicture() != null) {
            Image image = uiComponents.create(Image.class);
            image.setScaleMode(Image.ScaleMode.CONTAIN);
            image.setSource(FileStorageResource.class)
                    .setFileReference(user.getPicture());
            image.setWidth("50px");
            image.setHeight("50px");
            return image;
        } else {
            return null;
        }
    }

    @Install(to = "usersTable", subject = "styleProvider")
    private String usersTableStyleProvider(final User entity, final String property) {

        if (Boolean.TRUE.equals(entity.getActive()==true)) {
            return "active-user";
        }
        else
        {
            return "inactive-user";
        }
    }
}