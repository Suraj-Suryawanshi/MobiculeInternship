package com.company.jmix_drill.screen.timeentry;

import com.company.jmix_drill.entity.User;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.action.entitypicker.EntityLookupAction;
import io.jmix.ui.component.EntityPicker;
import io.jmix.ui.screen.*;
import com.company.jmix_drill.entity.TimeEntry;
import org.springframework.beans.factory.annotation.Autowired;

import javax.inject.Named;

@UiController("TimeEntry.edit")
@UiDescriptor("time-entry-edit.xml")
@EditedEntityContainer("timeEntryDc")
public class TimeEntryEdit extends StandardEditor<TimeEntry> {
    @Named("assigneeField.entityLookup")
    private EntityLookupAction<User> assigneeFieldEntityLookup;
    @Autowired
    private ScreenBuilders screenBuilders;

//    @Subscribe
//    public void onInit(final InitEvent event) {
//       assigneeFieldEntityLookup.addActionPerformedListener(actionPerformedEvent -> {screenBuilders.screen(this).withScreenClass(t)})
//    }
}