package com.company.jmix_drill.screen.task;

import com.company.jmix_drill.app.TaskService;
import com.company.jmix_drill.entity.TaskStatus;
import com.company.jmix_drill.entity.User;
import io.jmix.core.DataManager;
import io.jmix.core.security.CurrentAuthentication;
import io.jmix.ui.component.ComboBox;
import io.jmix.ui.component.EntityComboBox;
import io.jmix.ui.screen.*;
import com.company.jmix_drill.entity.Task;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@UiController("Task_.edit")
@UiDescriptor("task-edit.xml")
@EditedEntityContainer("taskDc")
public class TaskEdit extends StandardEditor<Task> {
    @Autowired
    private TaskService taskService;

    @Autowired
    private ComboBox<TaskStatus> taskStatusField;
    @Autowired
    private CurrentAuthentication currentAuthentication;
    @Autowired
    private DataManager dataManager;

    @Autowired
    private EntityComboBox<User> assigneeField;

    @Subscribe
    public void onInit(final InitEvent event) {
        List<User> user=dataManager.load(User.class)
                .query("select e from User e where e.active=false ")
//                .parameter("members", UserRole.MEMBERS)
                .list();

        assigneeField.setOptionsList(user);
    }

    @Subscribe
    public void onInitEntity1(final InitEntityEvent<Task> event) {
        Task task = event.getEntity();
        task.setTaskStatus(TaskStatus.INCOMPLETE);

//        task.setOnboardingStatus(OnboardingStatus.NOT_STARTED);
    }

    @Subscribe
    public void onInitEntity(final InitEntityEvent<Task> event) {
//        event.getEntity().setAssignee(taskService.findLeastBusyUser());
        event.getEntity().setManager((User) currentAuthentication.getUser());
    }

    @Subscribe
    public void onAfterCommitChanges(final AfterCommitChangesEvent event) {


    }
    
    
}