package com.company.jmix_drill.app;

import org.springframework.stereotype.Component;

@Component
public class UserService {

}