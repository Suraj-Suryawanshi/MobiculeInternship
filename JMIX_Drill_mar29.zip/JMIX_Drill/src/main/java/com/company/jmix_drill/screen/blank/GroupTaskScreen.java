package com.company.jmix_drill.screen.blank;

import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;

@UiController("GroupTaskScreen")
@UiDescriptor("blank-screen.xml")
public class GroupTaskScreen extends Screen {
}