package com.company.jmix_drill.screen.viewtaskonstatus;

import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;

@UiController("Viewtaskonstatus")
@UiDescriptor("ViewTaskOnStatus.xml")
public class Viewtaskonstatus extends Screen {
}