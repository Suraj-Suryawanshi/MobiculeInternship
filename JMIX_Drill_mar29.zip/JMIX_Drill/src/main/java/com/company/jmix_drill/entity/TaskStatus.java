package com.company.jmix_drill.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum TaskStatus implements EnumClass<Integer> {

    INCOMPLETE(10),
    COMPLETE(20),
    IN_PROGRESS(30);

    private final Integer id;

    TaskStatus(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    @Nullable
    public static TaskStatus fromId(Integer id) {
        for (TaskStatus at : TaskStatus.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}