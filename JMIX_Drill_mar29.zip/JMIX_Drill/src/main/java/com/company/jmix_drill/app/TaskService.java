package com.company.jmix_drill.app;

import com.company.jmix_drill.entity.Project;
import com.company.jmix_drill.entity.Task;
import com.company.jmix_drill.entity.User;
import com.company.jmix_drill.screen.user.UserEdit;
import io.jmix.core.DataManager;
import io.jmix.core.security.CurrentAuthentication;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
public class TaskService {
    private final DataManager dataManager;
    private final CurrentAuthentication currentAuthentication;
    private final Logger log = LoggerFactory.getLogger(UserEdit.class);
    public TaskService(DataManager dataManager, CurrentAuthentication currentAuthentication) {
        this.dataManager = dataManager;
        this.currentAuthentication = currentAuthentication;
    }

//    public User findLeastBusyUser() {
//        List<Object[]> resultList = (List<Object[]>) dataManager.loadValues("select u,count(t.id) " +
//                "from User u left outer join Task_ t " +
//                "on u = t.assignee " +
//                "group by u order by count(t.id)");
//
//        if (resultList.isEmpty()) {
//            throw new IllegalStateException("No users found");
//        }
//
//        User leastBusyUser = null;
//        Long leastTaskCount = Long.MAX_VALUE;
//
//        for (Object[] result : resultList) {
//            User user = (User) result[0];
//            Long taskCount = (Long) result[1];
//
//            if (taskCount < leastTaskCount) {
//                leastBusyUser = user;
//                leastTaskCount = taskCount;
//            }
//        }
//
//        log.warn("findLeastBusyUser:::InnerCallEnd" + leastBusyUser.toString());
//        return leastBusyUser;
//    }


    public User findLeastBusyUser(){
        User user=dataManager.loadValues("select u,count(t.id) " +
                        "from User u left outer join Task_ t " +
                        "on u = t.assignee " +
                        "group by u order by count(t.id)")
                .properties("user","tasks")
                .list().stream()
                .map(e->e.<User>getValue("user"))
                .findFirst()
                .orElseThrow(IllegalStateException::new);
                log.warn("findLeastBusyUser:::InnerCallEnd"+user.toString());
        return user;
    }

    public  void  createTask(Project project, String name, LocalDateTime startDate, Integer estimatedEfforts){
        Task  task = dataManager.create(Task.class);
        task.setProject(project);
        task.setName(name);
        task.setStartDate(startDate);
        task.setEstimatedEfforts(estimatedEfforts);
        task.setAssignee(findLeastBusyUser());
        task.setManager((User) currentAuthentication.getUser());

        dataManager.save(task);
    }


}